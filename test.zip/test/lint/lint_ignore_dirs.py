SHARED_EXCLUDED_SUBTREES = ["src/leveldb/",
                 "src/crc32c/",
                 "src/secp256k1/",
                 "src/minisketch/",
                ]
